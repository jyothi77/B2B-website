<?php

namespace GummiIO\AcfComponentField;

/**
 * Updater Class
 *
 * Class which handles the plugin updates [WIP]
 *
 * @since   2.0.0
 * @version 2.0.0
 */
class Updater
{
	public function __construct()
	{

	}
}
